"""
Futronic API - Servico Windows
Roda em background como servico do Windows.
"""

import win32serviceutil
import win32service
import win32event
import servicemanager
import socket
import sys
import os
import threading
import uvicorn

# Adiciona o diretorio atual ao path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import app

class FutronicService(win32serviceutil.ServiceFramework):
    _svc_name_ = "FutronicAPI"
    _svc_display_name_ = "Futronic API - Leitor Biometrico"
    _svc_description_ = "Servico de comunicacao com leitor biometrico Futronic FS80H para sistema de ponto eletronico."

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.server = None
        self.thread = None
        socket.setdefaulttimeout(60)

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        if self.server:
            self.server.should_exit = True

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, '')
        )
        self.main()

    def main(self):
        config = uvicorn.Config(app, host="0.0.0.0", port=5001, log_level="info")
        self.server = uvicorn.Server(config)

        # Roda o servidor em uma thread
        self.thread = threading.Thread(target=self.server.run)
        self.thread.start()

        # Aguarda sinal de parada
        win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)


if __name__ == '__main__':
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(FutronicService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(FutronicService)
