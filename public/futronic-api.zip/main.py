"""
Futronic API - Servico local para leitor biometrico Futronic FS80H
Roda na porta 5001 e expoe API REST para o sistema de ponto eletronico.

Uso:
    python main.py
    ou
    uvicorn main:app --host 0.0.0.0 --port 5001
"""

import os
import sys
import base64
import ctypes
import time
from pathlib import Path
from io import BytesIO
from typing import Optional
import threading

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from PIL import Image

# Configuracoes
PORT = 5001
FUTRONIC_DLL = "ftrScanAPI.dll"

# Inicializa FastAPI
app = FastAPI(
    title="Futronic API",
    description="API local para leitor biometrico Futronic FS80H",
    version="1.0.0"
)

# CORS para permitir chamadas do navegador
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Estado global
device_connected = False
device_handle = None
ftr_lib = None
last_image = None
capturing = False

# Estruturas do SDK Futronic
class FTRSCAN_IMAGE_SIZE(ctypes.Structure):
    _fields_ = [
        ("nWidth", ctypes.c_int),
        ("nHeight", ctypes.c_int),
        ("nImageSize", ctypes.c_int),
    ]

class FTRSCAN_DEVICE_INFO(ctypes.Structure):
    _fields_ = [
        ("nDeviceVersion", ctypes.c_int),
        ("szManufacturer", ctypes.c_char * 256),
        ("szProductName", ctypes.c_char * 256),
        ("szSerialNumber", ctypes.c_char * 256),
    ]


def load_futronic_sdk():
    """Carrega a DLL do Futronic SDK"""
    global ftr_lib

    # Tenta encontrar a DLL
    dll_paths = [
        FUTRONIC_DLL,
        os.path.join(os.path.dirname(__file__), FUTRONIC_DLL),
        r"C:\Program Files\Futronic\SDK\ftrScanAPI.dll",
        r"C:\Program Files (x86)\Futronic\SDK\ftrScanAPI.dll",
        r"C:\Windows\System32\ftrScanAPI.dll",
    ]

    for path in dll_paths:
        try:
            ftr_lib = ctypes.WinDLL(path)
            print(f"[Futronic] SDK carregado: {path}")
            return True
        except Exception as e:
            continue

    print("[Futronic] AVISO: SDK nao encontrado. Modo simulacao ativado.")
    return False


def init_device():
    """Inicializa o dispositivo Futronic"""
    global device_connected, device_handle, ftr_lib

    if ftr_lib is None:
        device_connected = False
        return False

    try:
        # Abre o dispositivo
        ftr_lib.ftrScanOpenDevice.restype = ctypes.c_void_p
        device_handle = ftr_lib.ftrScanOpenDevice()

        if device_handle:
            device_connected = True
            print("[Futronic] Dispositivo conectado!")
            return True
        else:
            device_connected = False
            print("[Futronic] Dispositivo nao encontrado")
            return False

    except Exception as e:
        print(f"[Futronic] Erro ao inicializar: {e}")
        device_connected = False
        return False


def capture_fingerprint():
    """Captura uma digital do leitor"""
    global device_handle, ftr_lib, last_image

    if not device_connected or ftr_lib is None:
        return None

    try:
        # Obtem tamanho da imagem
        img_size = FTRSCAN_IMAGE_SIZE()
        ftr_lib.ftrScanGetImageSize(device_handle, ctypes.byref(img_size))

        # Aloca buffer para a imagem
        buffer = (ctypes.c_ubyte * img_size.nImageSize)()

        # Captura a imagem
        result = ftr_lib.ftrScanGetFrame(device_handle, buffer, None)

        if result:
            # Converte para imagem PIL
            img = Image.frombytes('L', (img_size.nWidth, img_size.nHeight), bytes(buffer))

            # Converte para base64
            buffered = BytesIO()
            img.save(buffered, format="PNG")
            img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')

            last_image = img_base64
            return img_base64

        return None

    except Exception as e:
        print(f"[Futronic] Erro na captura: {e}")
        return None


def get_device_info():
    """Obtem informacoes do dispositivo"""
    global device_handle, ftr_lib

    if not device_connected or ftr_lib is None:
        return None

    try:
        info = FTRSCAN_DEVICE_INFO()
        ftr_lib.ftrScanGetDeviceInfo(device_handle, ctypes.byref(info))

        return {
            "manufacturer": info.szManufacturer.decode('utf-8', errors='ignore').strip(),
            "model": info.szProductName.decode('utf-8', errors='ignore').strip(),
            "serial": info.szSerialNumber.decode('utf-8', errors='ignore').strip(),
        }
    except:
        return {"manufacturer": "Futronic", "model": "FS80H", "serial": "Unknown"}


# ============ ENDPOINTS ============

@app.get("/")
async def root():
    """Status do servico e dispositivo"""
    return {
        "status": "online",
        "device_connected": device_connected,
        "version": "1.0.0"
    }


@app.get("/status")
async def status():
    """Status do servico (compatibilidade)"""
    return {
        "status": "online",
        "device_connected": device_connected,
        "version": "1.0.0"
    }


@app.get("/health")
async def health():
    """Health check"""
    return {"status": "healthy"}


@app.get("/device/status")
async def device_status():
    """Status detalhado do dispositivo"""
    info = get_device_info() if device_connected else None
    return {
        "connected": device_connected,
        "manufacturer": info["manufacturer"] if info else None,
        "model": info["model"] if info else None,
        "serial": info["serial"] if info else None,
    }


@app.post("/device/reconnect")
async def reconnect():
    """Tenta reconectar ao dispositivo"""
    success = init_device()
    return {"success": success, "connected": device_connected}


class CaptureRequest(BaseModel):
    timeout: Optional[int] = 10  # segundos


@app.post("/capture")
@app.post("/capturar")
async def capture(request: CaptureRequest = CaptureRequest()):
    """Captura uma digital"""
    global capturing

    if not device_connected:
        raise HTTPException(status_code=503, detail="Dispositivo nao conectado")

    if capturing:
        raise HTTPException(status_code=409, detail="Captura em andamento")

    capturing = True
    try:
        # Tenta capturar por ate timeout segundos
        start_time = time.time()
        while time.time() - start_time < request.timeout:
            img = capture_fingerprint()
            if img:
                return {
                    "success": True,
                    "image_base64": f"data:image/png;base64,{img}",
                    "template_base64": img,  # Template para o frontend
                    "template": img,  # Compatibilidade
                    "quality": 80  # Placeholder - SDK real retorna qualidade
                }
            time.sleep(0.5)

        raise HTTPException(status_code=408, detail="Timeout na captura")

    finally:
        capturing = False


@app.get("/capture/status")
async def capture_status():
    """Status da captura atual"""
    return {
        "capturing": capturing,
        "device_connected": device_connected
    }


@app.post("/capture/cancel")
async def cancel_capture():
    """Cancela captura em andamento"""
    global capturing
    capturing = False
    return {"success": True}


# ============ MODO SIMULACAO (sem SDK) ============

def simulate_fingerprint():
    """Gera uma imagem de digital simulada para testes"""
    import random

    # Cria imagem cinza com padrao de digital simulado
    width, height = 256, 288
    img = Image.new('L', (width, height), color=200)

    # Adiciona ruido para simular textura
    pixels = img.load()
    for i in range(width):
        for j in range(height):
            noise = random.randint(-30, 30)
            value = max(0, min(255, 200 + noise))
            pixels[i, j] = value

    # Converte para base64
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode('utf-8')


@app.post("/simulate/capture")
async def simulate_capture():
    """Captura simulada para testes (sem leitor real)"""
    img = simulate_fingerprint()
    return {
        "success": True,
        "simulated": True,
        "image_base64": f"data:image/png;base64,{img}",
        "quality": 75
    }


# ============ STARTUP ============

@app.on_event("startup")
async def startup_event():
    """Inicializacao do servidor"""
    print("=" * 50)
    print("Futronic API - Leitor Biometrico")
    print("=" * 50)
    print(f"Porta: {PORT}")
    print("")

    # Tenta carregar SDK e inicializar dispositivo
    if load_futronic_sdk():
        init_device()
    else:
        print("")
        print("MODO SIMULACAO ATIVO")
        print("Para usar o leitor real, instale o Futronic SDK")
        print("e coloque ftrScanAPI.dll na pasta do programa.")

    print("")
    print(f"Acesse: http://localhost:{PORT}")
    print("=" * 50)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT)
