============================================
  EXTENSAO DO LEITOR BIOMETRICO FUTRONIC
  Para Chrome, Edge, Brave e Firefox
============================================

INSTALACAO NO CHROME/EDGE/BRAVE:
--------------------------------
1. Abra o navegador
2. Digite na barra de endereco: chrome://extensions
3. Ative o "Modo do desenvolvedor" (canto superior direito)
4. Clique em "Carregar sem compactacao"
5. Selecione a pasta da extensao
6. Pronto! O icone aparecera na barra de ferramentas

INSTALACAO NO FIREFOX:
----------------------
1. Abra o Firefox
2. Digite na barra de endereco: about:debugging
3. Clique em "Este Firefox" no menu lateral
4. Clique em "Carregar extensao temporaria"
5. Selecione o arquivo manifest.json desta pasta
6. Pronto! O icone aparecera na barra de ferramentas

CORES DO ICONE:
---------------
VERDE  = Servico online e leitor conectado
AMARELO = Servico online mas leitor desconectado
VERMELHO = Servico offline (nao instalado)

FUNCIONALIDADES:
----------------
- Mostra status do servico do leitor na barra do navegador
- Verifica automaticamente a cada 30 segundos
- Botao para verificar manualmente
- Link para baixar o software se nao estiver instalado
- Link para abrir o sistema de ponto

REQUISITOS:
-----------
- Futronic API instalado (servico Windows)
- Leitor Futronic FS80H conectado via USB

SUPORTE:
--------
Sistema de Ponto Eletronico
https://ponto.mdevelop.com.br
