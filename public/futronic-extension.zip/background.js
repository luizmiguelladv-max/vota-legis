// Futronic Extension - Background Script (Firefox/Chrome compatible)

const API_URL = 'http://localhost:5001';

// Compatibilidade Firefox/Chrome
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

let lastStatus = { online: false, deviceConnected: false };

// Verifica status da API
async function checkApiStatus() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    const response = await fetch(`${API_URL}/status`, {
      method: 'GET',
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) throw new Error('Erro');

    const data = await response.json();
    const deviceConnected = data.device_connected || data.dispositivo_conectado || false;

    updateIcon(true, deviceConnected);
    lastStatus = { online: true, deviceConnected };

  } catch (error) {
    updateIcon(false, false);
    lastStatus = { online: false, deviceConnected: false };
  }
}

// Atualiza icone da extensao
function updateIcon(online, deviceConnected) {
  let iconPath, title;

  if (online && deviceConnected) {
    iconPath = {
      16: 'icons/icon-online-16.png',
      32: 'icons/icon-online-32.png',
      48: 'icons/icon-online-48.png',
      128: 'icons/icon-online-128.png'
    };
    title = 'Futronic - Leitor Conectado';
  } else if (online) {
    iconPath = {
      16: 'icons/icon-warning-16.png',
      32: 'icons/icon-warning-32.png',
      48: 'icons/icon-warning-48.png',
      128: 'icons/icon-warning-128.png'
    };
    title = 'Futronic - Leitor Desconectado';
  } else {
    iconPath = {
      16: 'icons/icon-offline-16.png',
      32: 'icons/icon-offline-32.png',
      48: 'icons/icon-offline-48.png',
      128: 'icons/icon-offline-128.png'
    };
    title = 'Futronic - Servico Offline';
  }

  // Usa browserAction para Manifest V2
  browserAPI.browserAction.setIcon({ path: iconPath });
  browserAPI.browserAction.setTitle({ title });
}

// Recebe mensagens do popup
browserAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'status') {
    updateIcon(message.online, message.deviceConnected);
    lastStatus = { online: message.online, deviceConnected: message.deviceConnected };
  }
  return true;
});

// Configura alarme para verificacao periodica
browserAPI.alarms.create('checkStatus', { periodInMinutes: 0.5 });

browserAPI.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkStatus') {
    checkApiStatus();
  }
});

// Verifica ao iniciar
checkApiStatus();
