// Futronic Extension - Popup Script (Firefox/Chrome compatible)

const API_URL = 'http://localhost:5001';

// Compatibilidade Firefox/Chrome
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

async function checkStatus() {
  const serviceStatus = document.getElementById('serviceStatus');
  const deviceStatus = document.getElementById('deviceStatus');
  const deviceInfo = document.getElementById('deviceInfo');
  const deviceName = document.getElementById('deviceName');
  const alertOffline = document.getElementById('alertOffline');
  const btnDownload = document.getElementById('btnDownload');
  const btnRefresh = document.getElementById('btnRefresh');

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    const response = await fetch(`${API_URL}/status`, {
      method: 'GET',
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) throw new Error('Erro na resposta');

    const data = await response.json();

    // Servico online
    serviceStatus.innerHTML = `
      <span class="status-dot online"></span>
      <span class="status-online">Online</span>
    `;

    // Verifica dispositivo
    if (data.device_connected || data.dispositivo_conectado) {
      deviceStatus.innerHTML = `
        <span class="status-dot online"></span>
        <span class="status-online">Conectado</span>
      `;
      deviceInfo.classList.remove('hidden');
      deviceName.textContent = data.device_name || data.dispositivo || 'Futronic FS80H';
    } else {
      deviceStatus.innerHTML = `
        <span class="status-dot warning"></span>
        <span class="status-warning">Desconectado</span>
      `;
      deviceInfo.classList.add('hidden');
    }

    alertOffline.classList.add('hidden');
    btnDownload.classList.add('hidden');
    btnRefresh.classList.remove('hidden');

    // Notifica background
    browserAPI.runtime.sendMessage({ type: 'status', online: true, deviceConnected: data.device_connected || data.dispositivo_conectado });

  } catch (error) {
    // Servico offline
    serviceStatus.innerHTML = `
      <span class="status-dot offline"></span>
      <span class="status-offline">Offline</span>
    `;
    deviceStatus.innerHTML = `
      <span class="status-dot offline"></span>
      <span>-</span>
    `;
    deviceInfo.classList.add('hidden');
    alertOffline.classList.remove('hidden');
    btnDownload.classList.remove('hidden');
    btnRefresh.classList.remove('hidden');

    // Notifica background
    browserAPI.runtime.sendMessage({ type: 'status', online: false, deviceConnected: false });
  }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  checkStatus();

  document.getElementById('btnRefresh').addEventListener('click', () => {
    const btn = document.getElementById('btnRefresh');
    btn.innerHTML = '<div class="spinner"></div> Verificando...';
    btn.disabled = true;

    setTimeout(() => {
      checkStatus();
      btn.innerHTML = '&#8635; Verificar Novamente';
      btn.disabled = false;
    }, 1000);
  });
});
